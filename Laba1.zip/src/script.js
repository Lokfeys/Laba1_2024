// Функции выполнения арифметических операций
function add(a, b) {
  return a + b;
}

function subtract(a, b) {
  return a - b;
}

function multiply(a, b) {
  return a * b;
}

function divide(a, b) {
  if (b === 0) {
    return "Ошибка: деление на ноль";
  } else if (a === 0){
    return "Ошибка: деление на ноль";
  } 
  else {
    return a / b;
  }
}

// Переменные получение чисел и оператора от пользователя и ввывода результата
let num1 = parseFloat(prompt("Введите первое число:"));
let num2 = parseFloat(prompt("Введите второе число:"));
let operator = prompt("Введите оператор (+, -, *, /):");

let result;

// Выполнение арифметической операции в зависимости от оператора
switch (operator) {
  case "+":
    result = add(num1, num2);
    break;
  case "-":
    result = subtract(num1, num2);
    break;
  case "*":
    result = multiply(num1, num2);
    break;
  case "/":
    result = divide(num1, num2);
    break;
  default:
    result = "Ошибка: неправильный оператор";
}

// Вывод результата
console.log("Первое число:", num1);
console.log("Оператор:", operator);
console.log("Второе число:", num2);
console.log("Результат:", result);

